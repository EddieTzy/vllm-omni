Thanks for the questions. I collected additional stage timing and CPU/CUDA traces to check the bottleneck attribution.

**Bottleneck and attribution.** In four independent diagnostic boots (baseline / patched / baseline / patched), the 32-token talker-forward host median was **34.639 / 35.248 ms** for baseline and **17.069 / 17.386 ms** for the patch. Corresponding decode-cycle medians were **51.641 / 52.167 ms** versus **34.193 / 34.582 ms**. The outside-forward remainder medians were **16.942 / 16.933 ms** versus **16.945 / 17.083 ms**. This remainder includes logits, sampling, scheduler/runner work and waiting; it is not a separate sampler timer.

Two real all-audio C32 forwards were traced per boot. All eight traces agree on the operation counts:

| Operation per forward | Baseline | Patched |
|---|---:|---:|
| `aten::any` | 168 | 0 |
| `aten::all` | 0 | 1 |
| `aten::item` | 168 | 1 |
| `aten::nonzero` | 169 | 1 |
| `aten::index` / `_index_put_impl_` | 84 / 84 | 0 / 0 |
| `cudaStreamSynchronize` runtime calls | 339 | 4 |
| `cudaLaunchKernel` runtime calls | 1,739 | 788 |

All 56 norm and 28 MLP helper calls remain. These observations locate the improvement in talker.forward and show the removed per-layer reduction/indexing/synchronization overhead. One forward-level scalar synchronization remains. The whole-forward counts include common preprocessing and profiler boundary effects.

**Value.** The original uninstrumented serving benchmark remains the basis for the 50.8% C32 audio-throughput claim and the first-audio latency results in the PR description. The additional diagnostics explain the mechanism; their client throughput is not substituted into that benchmark. Codec code is unchanged, and no codec speedup or memory reduction is claimed.

**A/B isolation and protocol.** The measured source pair is baseline `4dafb464442956996be9633ed036cd24ebfef1d0` and routing commit `30dcfdc205d17072734328e74c5ca96a882ec548`. The patched talker is byte-identical to current PR commit `c70831d97aea6a1ad038706b2b58af6609cefb26`. A comparison of all 2,381 runtime Python files per snapshot found only the talker differs, by the three published routing lines. Both diagnostic copies use identical instrumentation.

The hardware/model/configuration are the same pinned B200, Higgs v2 3B BF16 and two-stage MRv2 eager setup documented in the PR. Each diagnostic boot used 32 warmups followed by one wave of 32 requests from the existing interleaved EN/ZH corpus. All 256 requests including warmups succeeded. Non-trace forward medians above use 98/97 baseline samples and 89/107 patched samples after dropping the first 16 occurrences of the 32-token shape, traced forwards and the following two forwards. Forward P95 values were **35.488 / 36.484 ms** versus **17.503 / 17.715 ms**.

The stage summary covers real forwards in both client waves after those exclusions, rather than only the client's measured wave. The original controlled output-equivalence checks remain the correctness evidence. These new measurements provide stage attribution, but do not establish an exact additive request critical-path explanation for every percentage point of the original throughput gain. CUDA-event elapsed intervals include launch gaps and waits; they are not pure kernel compute time. Per-step samples within each boot are not independent experimental replicates.

<!-- Local preparation note: publish accessible trace/summary links alongside this reply before posting. Full report: higgs-routing-profiling-results.md; raw artifacts: b200-results/results/higgs-routing-profile/. This draft has not been posted. -->
